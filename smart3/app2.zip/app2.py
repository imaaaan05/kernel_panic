# =============================================================================
#  Smart Demand Signals — app.py (VERSIÓN REFACTORIZADA CON FEEDBACK INTELIGENTE)
#  Author : Equipo Inibsa
#  Purpose: Motor Estadístico 100% Pandas + Dashboard Streamlit
#
#  CAMBIOS VS. VERSIÓN ANTERIOR:
#  - Distinción Reloj (frecuencia) vs. Salud (volumen) en generate_alerts
#  - Falso Positivo → Penalty Weight 0.2 (no elimina la alerta, la degrada)
#  - Venta Recuperada → Penalty Weight 0.5 + estado "En Observación"
#    con chequeo de salud de volumen activo
#  - feedback_memory persiste en session_state con clave (Client_ID, Product_Family)
#  - st.data_editor dispara st.rerun() inmediatamente al registrar feedback
#  - Fórmula: Final_Score = Base_Score * Penalty_Weight
# =============================================================================

import pandas as pd
import numpy as np
import streamlit as st
import os
import tempfile
from datetime import datetime

# ─────────────────────────────────────────────────────────────────────────────
# 0. CONFIGURACIÓN Y MEMORIA (SESSION STATE)
# ─────────────────────────────────────────────────────────────────────────────
st.set_page_config(page_title="Smart Demand Signals · Inibsa", page_icon="💊", layout="wide")

# Inicializar la memoria de feedback si no existe
# Estructura: { (Client_ID, Product_Family): {"accion": str, "penalty": float} }
if "feedback_memory" not in st.session_state:
    st.session_state.feedback_memory = {}

st.markdown("""
    <style>
        .kpi-card { background: #f0f4ff; border: 1px solid #c9d9f7; border-radius: 10px; padding: 18px 22px; text-align: center; }
        .kpi-value { font-size: 2rem; font-weight: 800; color: #0d6efd; }
        .kpi-label { font-size: 0.8rem; color: #555; margin-top: 4px; text-transform: uppercase; letter-spacing: 0.05em; }
        .section-header { font-size: 1.1rem; font-weight: 700; color: #1a3a5c; border-left: 4px solid #0d6efd; padding-left: 10px; margin: 20px 0 10px; }
    </style>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────────────────
# 1. INGESTA Y LIMPIEZA DE DATOS
# ─────────────────────────────────────────────────────────────────────────────
@st.cache_data(show_spinner="Cargando y limpiando datos...")
def load_and_clean_data(filepath) -> pd.DataFrame:
    df = pd.read_csv(filepath, dtype=str, sep=';', encoding='latin1')
    rename_map = {
        "Id.Cliente": "Client_ID", "Fecha": "Date", "Familia_H": "Product_Family",
        "Unidades": "Quantity", "Valores_H": "Transaction_Value",
        "Potencial_H": "Client_Potential", "Bloque analítico": "Analytical_Block"
    }
    df = df.rename(columns=rename_map)

    for col in ["Quantity", "Transaction_Value", "Client_Potential"]:
        if col in df.columns:
            df[col] = df[col].str.replace(',', '.', regex=False)
            df[col] = pd.to_numeric(df[col], errors="coerce")

    if "Analytical_Block" in df.columns:
        df["Analytical_Block"] = df["Analytical_Block"].str.strip().replace(
            {'Productos Técnicos': 'Technical', 'Productos TÃ©cnicos': 'Technical'}
        )
    else:
        df["Analytical_Block"] = "Technical"

    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Client_ID", "Date", "Product_Family", "Quantity", "Transaction_Value"])
    df = df[(df["Quantity"] > 0) & (df["Transaction_Value"] > 0)].copy()

    df["Client_Potential"] = df["Client_Potential"].fillna(0)
    df["Client_ID"] = df["Client_ID"].astype(str).str.strip()

    return df

# ─────────────────────────────────────────────────────────────────────────────
# 2. FEATURE ENGINEERING Y AGRUPACIÓN
# ─────────────────────────────────────────────────────────────────────────────
def build_features(df: pd.DataFrame) -> pd.DataFrame:
    df["YearMonth"] = df["Date"].dt.to_period("M")
    monthly = df.groupby(["Client_ID", "YearMonth"])["Transaction_Value"].sum().reset_index()
    avg_monthly = (
        monthly.groupby("Client_ID")["Transaction_Value"]
        .mean().reset_index()
        .rename(columns={"Transaction_Value": "Average_Monthly_Spend"})
    )
    max_pot = (
        df.groupby("Client_ID")["Client_Potential"]
        .max().reset_index()
        .rename(columns={"Client_Potential": "Max_Client_Potential"})
    )

    loyalty_df = avg_monthly.merge(max_pot, on="Client_ID", how="left")
    loyalty_df["Loyalty_Factor"] = np.where(
        loyalty_df["Average_Monthly_Spend"] >= 0.85 * loyalty_df["Max_Client_Potential"],
        "Loyal", "Promiscuous"
    )

    df = df.merge(
        loyalty_df[["Client_ID", "Average_Monthly_Spend", "Max_Client_Potential", "Loyalty_Factor"]],
        on="Client_ID", how="left"
    )

    agg = df.groupby(["Client_ID", "Date", "Product_Family"], as_index=False).agg(
        Quantity=("Quantity", "sum"),
        Transaction_Value=("Transaction_Value", "sum"),
        Analytical_Block=("Analytical_Block", "first"),
        Loyalty_Factor=("Loyalty_Factor", "first"),
        Average_Monthly_Spend=("Average_Monthly_Spend", "first"),
        Max_Client_Potential=("Max_Client_Potential", "first")
    ).sort_values(["Client_ID", "Product_Family", "Date"]).reset_index(drop=True)

    agg["Days_Between"] = agg.groupby(["Client_ID", "Product_Family"])["Date"].diff().dt.days
    return agg


# ─────────────────────────────────────────────────────────────────────────────
# 3. MOTOR ESTADÍSTICO CON FEEDBACK INTELIGENTE
#
#  Distinción clave:
#   • RELOJ (Frecuencia): ¿Cuánto tiempo ha pasado desde la última compra?
#     → Si hay "Venta Recuperada", el reloj se resetea (Days_Since_Last lógico).
#       Pero el reloj solo importa si la compra también fue suficiente en volumen.
#
#   • SALUD (Volumen): ¿Fue la última cantidad comprada lo suficientemente alta?
#     → La alerta "Caída drástica de volumen" SIEMPRE permanece si el volumen
#       real está por debajo de Mean_Qty - 1.0 * Std_Qty, incluso con feedback
#       "Venta Recuperada". Solo se anula cuando los datos reales confirmen
#       la recuperación en el próximo refresco.
#
#  Reglas de Penalty Weight:
#   • ❌ Falso Positivo  → Penalty = 0.2 | Estado = "Ignorado por usuario"
#   • ✅ Venta Recuperada → Penalty = 0.5 | Estado = "En Observación"
#     EXCEPCIÓN: si el volumen aún es bajo → Penalty = 1.0 en la alerta de volumen
#                (mantiene el riesgo base intacto para esa dimensión de salud)
#
#  Fórmula final: Final_Score = Base_Score * Penalty_Weight
# ─────────────────────────────────────────────────────────────────────────────
def generate_alerts(agg: pd.DataFrame, today_simulated, feedback_memory: dict) -> pd.DataFrame:
    # ── Estadísticas por par (Client_ID, Product_Family) ──
    pair_stats = agg.groupby(["Client_ID", "Product_Family"]).agg(
        Purchase_Count=("Quantity", "count"),
        Mean_Qty=("Quantity", "mean"),
        Std_Qty=("Quantity", "std"),
        Mean_Days=("Days_Between", "mean"),
        Std_Days=("Days_Between", "std"),
        Avg_Txn_Value=("Transaction_Value", "mean")
    ).reset_index()

    # ── Estadísticas globales por familia (fallback cold-start) ──
    global_stats = agg.groupby("Product_Family").agg(
        G_Mean_Qty=("Quantity", "mean"),
        G_Std_Qty=("Quantity", "std"),
        G_Mean_Days=("Days_Between", "mean"),
        G_Std_Days=("Days_Between", "std")
    ).reset_index()

    stats = pair_stats.merge(global_stats, on="Product_Family", how="left")
    cold = stats["Purchase_Count"] < 3
    stats.loc[cold, "Std_Qty"]   = stats.loc[cold, "G_Std_Qty"]
    stats.loc[cold, "Std_Days"]  = stats.loc[cold, "G_Std_Days"]
    stats.loc[cold, "Mean_Qty"]  = stats.loc[cold, "G_Mean_Qty"]
    stats.loc[cold, "Mean_Days"] = stats.loc[cold, "G_Mean_Days"]
    stats.fillna(0, inplace=True)

    # ── Última compra y días transcurridos (usando fecha simulada) ──
    last_purchase = (
        agg.sort_values("Date")
        .groupby(["Client_ID", "Product_Family"])
        .last()
        .reset_index()
    )
    last_purchase["Days_Since_Last"] = (
        pd.Timestamp(today_simulated) - last_purchase["Date"]
    ).dt.days

    df_eval = last_purchase.merge(stats, on=["Client_ID", "Product_Family"], how="left")

    LIMITE_FUGA = 365
    alerts = []

    for _, row in df_eval.iterrows():
        if row["Mean_Days"] <= 0:
            continue

        block       = row["Analytical_Block"]
        loyal       = row["Loyalty_Factor"]
        dsl         = row["Days_Since_Last"]
        mean_days   = row["Mean_Days"]
        std_days    = row["Std_Days"]
        last_qty    = row["Quantity"]
        mean_qty    = row["Mean_Qty"]
        std_qty     = row["Std_Qty"]
        avg_spend   = row["Average_Monthly_Spend"]
        max_pot     = row["Max_Client_Potential"]
        llave       = (row["Client_ID"], row["Product_Family"])

        # ── Recuperar feedback previo para este par ──
        feedback_entry = feedback_memory.get(llave, {})
        feedback_accion  = feedback_entry.get("accion", "")
        feedback_penalty = feedback_entry.get("penalty", 1.0)   # 1.0 = sin penalización

        # ── Lógica de detección ──
        reason      = None
        opportunity = 0.0
        days_delayed = 0.0

        # ─── Bloque Commodities ───────────────────────────────────────────────
        if block == "Commodities" and loyal == "Promiscuous":
            if dsl > LIMITE_FUGA:
                reason       = "Fugado a la competencia (>1 año)"
                opportunity  = max_pot
                days_delayed = 0
            elif dsl >= mean_days:
                reason       = "Ventana de Captura"
                opportunity  = max(0, max_pot - avg_spend)
                days_delayed = dsl - mean_days

        # ─── Bloque Technical ────────────────────────────────────────────────
        elif block == "Technical":
            expected_days = (mean_days * (last_qty / mean_qty)) if mean_qty > 0 else mean_days

            # ── SALUD: Caída de volumen ──
            # Esta dimensión persiste independientemente del feedback de frecuencia.
            # Solo se anula si el propio feedback es "Falso Positivo" (penalty 0.2).
            volume_drop = (last_qty < mean_qty - (1.0 * std_qty))

            if dsl > LIMITE_FUGA:
                reason       = "Fugado a la competencia (>1 año)"
                opportunity  = max_pot
                days_delayed = 0
            elif dsl > expected_days + (1.5 * std_days):
                # ── RELOJ: Retraso anómalo ──
                # Si hay "Venta Recuperada", el reloj se resetea → esta alerta
                # recibe el penalty estándar de 0.5 (se degrada, no desaparece).
                # Si además hay caída de volumen, esa alerta se emite por separado
                # con penalty_volume = 1.0 (riesgo base intacto).
                reason       = "Retraso anómalo en tiempo"
                opportunity  = avg_spend
                days_delayed = max(0, dsl - expected_days)
            elif volume_drop:
                # Solo volumen bajo, sin retraso de tiempo
                reason       = "Caída drástica de volumen"
                opportunity  = avg_spend
                days_delayed = 0

        if not reason:
            continue

        # ─── Determinar Penalty Weight según feedback + lógica Reloj/Salud ───
        # Caso especial: "Venta Recuperada" + alerta de volumen
        #   → El reloj se considera resuelto, pero la SALUD permanece al 100%.
        #   → Emitimos la alerta de volumen con penalty = 1.0 (sin descuento).
        if (
            feedback_accion == "✅ Venta Recuperada"
            and reason == "Caída drástica de volumen"
        ):
            # Volumen insuficiente: la compra recuperada no fue suficiente.
            # Se ignora el penalty de "Venta Recuperada" para esta dimensión.
            penalty_weight = 1.0
            estado_feedback = "⚠️ Volumen Insuficiente"

        elif feedback_accion == "✅ Venta Recuperada":
            # Alerta de tiempo/fuga con venta recuperada: penalty normal 0.5
            penalty_weight  = 0.5
            estado_feedback = "En Observación"

        elif feedback_accion == "❌ Falso Positivo":
            # Penalty 0.2: alerta se degrada pero no desaparece
            penalty_weight  = 0.2
            estado_feedback = "Ignorado por usuario"

        else:
            penalty_weight  = 1.0
            estado_feedback = ""

        alerts.append({
            "Client_ID":                 row["Client_ID"],
            "Product_Family":            row["Product_Family"],
            "Analytical_Block":          block,
            "Motivo":                    reason,
            "Days_Since_Last":           dsl,
            "Days_Delayed":              days_delayed,
            "Mean_Days":                 mean_days,
            "Average_Transaction_Value": row["Avg_Txn_Value"],
            "Valor_Oportunidad (€)":     round(opportunity, 2),
            # Internos para cálculo de score
            "_penalty_weight":           penalty_weight,
            "_feedback_estado":          estado_feedback,
        })

    # ── Nada detectado ──
    if not alerts:
        return pd.DataFrame()

    alerts_df = pd.DataFrame(alerts)

    # ── Calcular Base Score (normalización logarítmica con cap) ──
    #
    #  Problema de la normalización lineal: un único cliente con valor económico
    #  muy alto (outlier) comprime todos los demás scores hacia 0, "aplastando"
    #  alertas legítimas de menor valor pero igual urgencia temporal.
    #
    #  Solución en dos pasos:
    #   1. Cap al percentil 95: los outliers extremos se recortan antes de
    #      normalizar, evitando que dominen la escala.
    #   2. Log-transform (log1p): comprime la cola larga del valor económico.
    #      Diferencias grandes en € producen diferencias pequeñas en score;
    #      diferencias pequeñas en € producen diferencias proporcionalmente
    #      más visibles → alertas de menor valor ya no quedan "aplastadas".
    #
    #  Fórmula: base_score = 1 + 99 * (log1p(min(raw, cap)) - log1p(r_min))
    #                                  ─────────────────────────────────────
    #                                  log1p(cap) - log1p(r_min)   [si rango > 0]
    raw_score = (
        alerts_df["Average_Transaction_Value"]
        * (1 + (alerts_df["Days_Delayed"] / alerts_df["Mean_Days"].replace(0, 1)))
    )
    cap_95    = raw_score.quantile(0.95)                 # techo en p95
    capped    = raw_score.clip(upper=cap_95)             # recortar outliers
    log_score = np.log1p(capped)                         # compresión logarítmica
    l_min, l_max = log_score.min(), log_score.max()
    if l_max == l_min:
        base_score = pd.Series([50] * len(alerts_df), dtype=float)
    else:
        base_score = 1 + 99 * (log_score - l_min) / (l_max - l_min)

    # ── Aplicar Penalty Weight: Final_Score = Base_Score * Penalty_Weight ──
    alerts_df["Nivel de Riesgo"] = (base_score * alerts_df["_penalty_weight"]).round(0).astype(int)

    # ── Actualizar Motivo con estado de feedback (cuando corresponda) ──
    mask_estado = alerts_df["_feedback_estado"] != ""
    alerts_df.loc[mask_estado, "Motivo"] = (
        alerts_df.loc[mask_estado, "Motivo"]
        + " ["
        + alerts_df.loc[mask_estado, "_feedback_estado"]
        + "]"
    )

    # ── Limpiar columnas internas ──
    alerts_df.drop(columns=["_penalty_weight", "_feedback_estado"], inplace=True)

    # ── Ordenar: mayor riesgo primero; los "Ignorado" van al fondo ──
    alerts_df = alerts_df.sort_values("Nivel de Riesgo", ascending=False).reset_index(drop=True)

    return alerts_df


# ─────────────────────────────────────────────────────────────────────────────
# 4. DASHBOARD UI
# ─────────────────────────────────────────────────────────────────────────────
st.markdown(
    "<h1>📡 Smart Demand Signals <span style='font-size:1rem;color:gray'>by Hackathon Team</span></h1>",
    unsafe_allow_html=True
)

with st.sidebar:
    st.header("⚙️ Configuración")
    uploaded_file = st.file_uploader("Sube database_clean.csv", type=["csv", "xlsx"])

    # Selector de fecha simulada
    st.divider()
    sim_date = st.date_input("Simular fecha actual:", value=datetime(2025, 12, 31))

    block_filter = st.selectbox("Bloque Analítico", ["Todos", "Commodities", "Technical"])
    min_risk = st.slider("Riesgo Mínimo", 0, 100, 20)

    # Botón para limpiar toda la memoria de feedback
    st.divider()
    if st.button("🗑️ Limpiar todo el Feedback"):
        st.session_state.feedback_memory = {}
        st.rerun()

data_path = "database_clean.csv" if os.path.exists("database_clean.csv") else None
if uploaded_file:
    with tempfile.NamedTemporaryFile(delete=False, suffix=".csv") as tmp:
        tmp.write(uploaded_file.read())
        data_path = tmp.name

if not data_path:
    st.info("👆 Por favor, sube el archivo 'database_clean.csv' en la barra lateral.")
    st.stop()

# ── Pipeline de ejecución ──
try:
    raw_df = load_and_clean_data(data_path)

    # Filtro de ruido: solo los últimos 2 años respecto a la fecha simulada
    fecha_limite = pd.Timestamp(sim_date) - pd.DateOffset(years=2)
    df_filtered = raw_df[
        (raw_df["Date"] >= fecha_limite) & (raw_df["Date"] <= pd.Timestamp(sim_date))
    ].copy()

    if df_filtered.empty:
        st.warning("No hay datos en el rango seleccionado.")
        st.stop()

    agg_df     = build_features(df_filtered)
    alerts_df  = generate_alerts(agg_df, sim_date, st.session_state.feedback_memory)

except Exception as e:
    st.error(f"Error en el pipeline: {e}")
    st.stop()

# ── Aplicar filtros UI ──
if not alerts_df.empty:
    if block_filter != "Todos":
        alerts_df = alerts_df[alerts_df["Analytical_Block"] == block_filter]
    alerts_df = alerts_df[alerts_df["Nivel de Riesgo"] >= min_risk]

# ── KPIs ──
col1, col2, col3, col4 = st.columns(4)
total_alerts   = len(alerts_df)
unique_clients = alerts_df["Client_ID"].nunique()   if not alerts_df.empty else 0
high_risk      = len(alerts_df[alerts_df["Nivel de Riesgo"] >= 70]) if not alerts_df.empty else 0
oportunidad    = alerts_df["Valor_Oportunidad (€)"].sum()            if not alerts_df.empty else 0

col1.markdown(f'<div class="kpi-card"><div class="kpi-value">{total_alerts}</div><div class="kpi-label">Alertas</div></div>', unsafe_allow_html=True)
col2.markdown(f'<div class="kpi-card"><div class="kpi-value">{unique_clients}</div><div class="kpi-label">Clínicas</div></div>', unsafe_allow_html=True)
col3.markdown(f'<div class="kpi-card"><div class="kpi-value">{high_risk}</div><div class="kpi-label">Riesgo Alto</div></div>', unsafe_allow_html=True)
col4.markdown(f'<div class="kpi-card"><div class="kpi-value">€{oportunidad:,.0f}</div><div class="kpi-label">Oportunidad</div></div>', unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# ── Tabla Interactiva con Feedback ──
st.markdown('<div class="section-header">🚨 Panel de Alertas Comerciales</div>', unsafe_allow_html=True)

if not alerts_df.empty:
    display_df = alerts_df[[
        "Client_ID", "Product_Family", "Analytical_Block",
        "Motivo", "Nivel de Riesgo", "Days_Since_Last", "Valor_Oportunidad (€)"
    ]].copy()

    # Pre-cargar acciones registradas previamente desde feedback_memory
    def _get_feedback_accion(row):
        entry = st.session_state.feedback_memory.get((row["Client_ID"], row["Product_Family"]), {})
        return entry.get("accion", "")

    display_df["Acción Comercial (Feedback)"] = display_df.apply(_get_feedback_accion, axis=1)

    edited_df = st.data_editor(
        display_df,
        use_container_width=True,
        hide_index=True,
        key="main_editor",
        column_config={
            "Nivel de Riesgo": st.column_config.ProgressColumn(
                "Riesgo", min_value=0, max_value=100, format="%d"
            ),
            "Valor_Oportunidad (€)": st.column_config.NumberColumn(
                "Valor", format="€%.2f"
            ),
            "Acción Comercial (Feedback)": st.column_config.SelectboxColumn(
                "Registrar Acción",
                options=["", "✅ Venta Recuperada", "❌ Falso Positivo", "⏳ Pendiente"]
            ),
        },
    )

    # ── Detectar cambios y persistir en feedback_memory ──
    # Los penalty weights correspondientes se asignan aquí para que
    # generate_alerts los aplique en el siguiente rerun.
    PENALTY_MAP = {
        "✅ Venta Recuperada": 0.5,
        "❌ Falso Positivo":   0.2,
        "⏳ Pendiente":        1.0,
        "":                    1.0,
    }

    changed = False
    for _, row in edited_df.iterrows():
        nueva_accion = row["Acción Comercial (Feedback)"]
        llave        = (row["Client_ID"], row["Product_Family"])
        entrada_prev = st.session_state.feedback_memory.get(llave, {})
        accion_prev  = entrada_prev.get("accion", "")

        if nueva_accion != "" and nueva_accion != accion_prev:
            st.session_state.feedback_memory[llave] = {
                "accion":  nueva_accion,
                "penalty": PENALTY_MAP.get(nueva_accion, 1.0),
            }
            changed = True

    # Rerun inmediato para aplicar visualmente los Penalty Weights
    if changed:
        st.rerun()

else:
    st.success("✅ No se han detectado alertas con los filtros actuales.")

# ── Resumen de Feedback activo ──
if st.session_state.feedback_memory:
    with st.expander(f"📋 Feedback registrado ({len(st.session_state.feedback_memory)} entradas)"):
        fb_rows = [
            {
                "Cliente":          k[0],
                "Familia":          k[1],
                "Acción":           v["accion"],
                "Penalty Weight":   v["penalty"],
            }
            for k, v in st.session_state.feedback_memory.items()
        ]
        st.dataframe(pd.DataFrame(fb_rows), use_container_width=True, hide_index=True)

with st.expander("📚 Metodología"):
    st.markdown("""
    **Filtro de Ruido:** Solo analiza los últimos 2 años para evitar sesgos de datos obsoletos.

    **Distinción Reloj vs. Salud:**
    - 🕐 *Reloj (Frecuencia):* Mide el tiempo desde la última compra. Al registrar "Venta Recuperada", el reloj se considera resuelto (penalty 0.5).
    - 💚 *Salud (Volumen):* Si el volumen de la última compra está por debajo de `Mean_Qty - 1.0 × Std_Qty`, la alerta de "Caída drástica de volumen" **permanece activa** independientemente del feedback de frecuencia.

    **Penalty Weights:**
    | Acción           | Peso | Estado visible          |
    |------------------|------|-------------------------|
    | ❌ Falso Positivo | 0.2  | Ignorado por usuario     |
    | ✅ Venta Recuperada | 0.5 | En Observación          |
    | ⚠️ Vol. Insuficiente | 1.0 | Volumen Insuficiente   |
    | Sin feedback     | 1.0  | —                        |

    **Fórmula:** `Final_Score = Base_Score × Penalty_Weight`

    **Normalización del Score (log + cap):**
    El valor económico bruto se somete a dos transformaciones antes de normalizar:
    1. **Cap p95** — los outliers de alto valor se recortan al percentil 95, evitando que un único cliente de gran ticket comprima al resto hacia 0.
    2. **log1p** — compresión logarítmica de la cola larga: diferencias grandes en € producen diferencias pequeñas en score, de modo que alertas de menor valor económico pero alta urgencia temporal mantienen scores visibles.
    """)